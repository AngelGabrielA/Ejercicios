import java.util.*;
public class VehiculoMain{
 public static void main(String[]a){System.out.println("hola");}
}
