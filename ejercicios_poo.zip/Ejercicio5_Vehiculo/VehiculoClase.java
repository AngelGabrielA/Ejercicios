public class VehiculoClase {
    private int x;
    public VehiculoClase(){}
}
