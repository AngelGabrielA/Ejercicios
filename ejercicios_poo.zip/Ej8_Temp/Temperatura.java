public class Temperatura{
 private double valor; private String uni; private String fecha;
 public Temperatura(double v,String u,String f){valor=v;uni=u;fecha=f;}
 public double getValor(){return valor;} public void setValor(double v){valor=v;}
 public String getUni(){return uni;} public void setUni(String v){uni=v;}
 public String getFecha(){return fecha;} public void setFecha(String v){fecha=v;}
 public void convertir(){
  if(uni.equalsIgnoreCase("C")){
   valor = valor*9/5+32; uni="F";
  }else{
   valor = (valor-32)*5/9; uni="C";
  }
 }
 public boolean extrema(){
  if(uni.equalsIgnoreCase("C")) return valor>40;
  double c=(valor-32)*5/9; return c>40;
 }
}