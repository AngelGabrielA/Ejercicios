import java.util.*;
public class TemperaturaMain{
 public static void main(String[]args){
 Scanner sc=new Scanner(System.in);
 System.out.print("Valor: ");double v=sc.nextDouble();
 sc.nextLine();
 System.out.print("Uni(C/F): ");String u=sc.nextLine();
 System.out.print("Fecha: ");String f=sc.nextLine();
 Temperatura t=new Temperatura(v,u,f);
 t.convertir();
 System.out.println("Convertida a "+t.getUni()+": "+t.getValor());
 System.out.println("¿Extrema? "+t.extrema());
 }
}