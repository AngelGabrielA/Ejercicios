public class ProductoAlmacen {
 private String ref;
 private int cantidad;
 private double precio;
 public ProductoAlmacen(String r,int c,double p){ref=r;cantidad=c;precio=p;}
 public String getRef(){return ref;} public void setRef(String v){ref=v;}
 public int getCantidad(){return cantidad;} public void setCantidad(int v){cantidad=v;}
 public double getPrecio(){return precio;} public void setPrecio(double v){precio=v;}
 public void entrada(int e){cantidad+=e;}
 public double valorTotal(){return cantidad*precio;}
}