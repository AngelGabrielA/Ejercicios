import java.util.Scanner;
public class ProductoAlmacenMain{
 public static void main(String[]a){
  Scanner sc=new Scanner(System.in);
  System.out.print("Ref: ");String r=sc.nextLine();
  System.out.print("Cantidad: ");int c=sc.nextInt();
  System.out.print("Precio: ");double p=sc.nextDouble();
  ProductoAlmacen x=new ProductoAlmacen(r,c,p);
  System.out.print("Entrada cantidad: ");int e=sc.nextInt();
  x.entrada(e);
  System.out.println("Valor total: "+x.valorTotal());
 }
}