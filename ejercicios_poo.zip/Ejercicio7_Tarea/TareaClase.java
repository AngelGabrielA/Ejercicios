public class TareaClase {
    private int x;
    public TareaClase(){}
}
