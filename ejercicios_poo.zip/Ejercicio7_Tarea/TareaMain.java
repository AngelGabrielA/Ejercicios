import java.util.*;
public class TareaMain{
 public static void main(String[]a){System.out.println("hola");}
}
