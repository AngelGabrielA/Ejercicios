import java.util.*;
public class CuentaAhorroMain{
 public static void main(String[]args){
 Scanner sc=new Scanner(System.in);
 System.out.print("Num cuenta: ");String n=sc.nextLine();
 System.out.print("Titular: ");String t=sc.nextLine();
 System.out.print("Saldo: ");double s=sc.nextDouble();
 CuentaAhorro c=new CuentaAhorro(n,t,s);
 System.out.print("Deposito: ");double d=sc.nextDouble();c.deposito(d);
 System.out.print("Retiro: ");double r=sc.nextDouble();
 System.out.println("Retiro ok? "+c.retiro(r));
 }
}