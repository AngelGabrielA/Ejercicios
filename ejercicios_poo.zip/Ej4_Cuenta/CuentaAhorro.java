public class CuentaAhorro{
 private String num; private String titular; private double saldo;
 public CuentaAhorro(String n,String t,double s){num=n;titular=t;saldo=s;}
 public String getNum(){return num;} public void setNum(String v){num=v;}
 public String getTitular(){return titular;} public void setTitular(String v){titular=v;}
 public double getSaldo(){return saldo;} public void setSaldo(double v){saldo=v;}
 public void deposito(double d){saldo+=d;}
 public boolean retiro(double r){ if(r<=saldo){saldo-=r;return true;} return false;}
}