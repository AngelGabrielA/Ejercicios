public class Libro {
    private String id;
    private String autor;
    private boolean disponible;
    private int anios;

    public Libro(String id, String autor, boolean disponible, int anios){
        this.id=id; this.autor=autor; this.disponible=disponible; this.anios=anios;
    }
    public String getId(){return id;}
    public void setId(String v){id=v;}
    public String getAutor(){return autor;}
    public void setAutor(String v){autor=v;}
    public boolean isDisponible(){return disponible;}
    public void setDisponible(boolean v){disponible=v;}
    public int getAnios(){return anios;}
    public void setAnios(int v){anios=v;}

    public void reservar(){ if(disponible) disponible=false; }
    public boolean esApto(){ return anios>5; }
}