import java.util.Scanner;
public class LibroMain {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.print("ID del libro: ");
        String id=sc.nextLine();
        System.out.print("Autor: ");
        String autor=sc.nextLine();
        System.out.print("Años desde publicación: ");
        int a=sc.nextInt();
        Libro l=new Libro(id,autor,true,a);
        l.reservar();
        System.out.println("Reservado. ¿Es apto? "+l.esApto());
    }
}