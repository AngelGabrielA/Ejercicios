import java.util.*;
public class VueloMain{
 public static void main(String[]a){
 Scanner sc=new Scanner(System.in);
 System.out.print("Codigo: ");String c=sc.nextLine();
 System.out.print("Capacidad: ");int cap=sc.nextInt();
 System.out.print("Reservados: ");int r=sc.nextInt();
 Vuelo v=new Vuelo(c,cap,r);
 System.out.println("Reserva hecha? "+v.reservar());
 System.out.println("Ocupacion: "+v.ocup());
 }
}