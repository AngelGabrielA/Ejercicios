public class Vuelo{
 private String cod; private int cap; private int res;
 public Vuelo(String c,int ca,int r){cod=c;cap=ca;res=r;}
 public String getCod(){return cod;} public void setCod(String v){cod=v;}
 public int getCap(){return cap;} public void setCap(int v){cap=v;}
 public int getRes(){return res;} public void setRes(int v){res=v;}
 public boolean reservar(){ if(res<cap){res++;return true;} return false; }
 public double ocup(){ return (res*100.0)/cap; }
}