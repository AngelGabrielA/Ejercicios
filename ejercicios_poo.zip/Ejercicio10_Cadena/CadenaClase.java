public class CadenaClase {
    private int x;
    public CadenaClase(){}
}
