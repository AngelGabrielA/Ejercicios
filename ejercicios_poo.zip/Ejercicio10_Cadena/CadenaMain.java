import java.util.*;
public class CadenaMain{
 public static void main(String[]a){System.out.println("hola");}
}
