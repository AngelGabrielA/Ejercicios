public class TemperaturaClase {
    private int x;
    public TemperaturaClase(){}
}
