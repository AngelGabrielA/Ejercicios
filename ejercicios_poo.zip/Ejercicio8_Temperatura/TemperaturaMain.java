import java.util.*;
public class TemperaturaMain{
 public static void main(String[]a){System.out.println("hola");}
}
