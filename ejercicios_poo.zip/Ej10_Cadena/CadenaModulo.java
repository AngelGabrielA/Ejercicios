public class CadenaModulo{
 private String cad; private String id; private int max;
 public CadenaModulo(String c,String i,int m){cad=c;id=i;max=m;}
 public String getCad(){return cad;} public void setCad(String v){cad=v;}
 public String getId(){return id;} public void setId(String v){id=v;}
 public int getMax(){return max;} public void setMax(int v){max=v;}
 public String prefijar(String p){ return p+cad; }
 public int contarEsp(){
  int cont=0;
  for(char x: cad.toCharArray()) if(x==' ') cont++;
  return cont;
 }
}