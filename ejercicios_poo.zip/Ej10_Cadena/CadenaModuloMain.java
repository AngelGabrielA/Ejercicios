import java.util.*;
public class CadenaModuloMain{
 public static void main(String[]a){
 Scanner sc=new Scanner(System.in);
 System.out.print("Cadena: ");String c=sc.nextLine();
 System.out.print("ID: ");String i=sc.nextLine();
 System.out.print("Max: ");int m=sc.nextInt();
 sc.nextLine();
 CadenaModulo x=new CadenaModulo(c,i,m);
 System.out.print("Prefijo: ");String p=sc.nextLine();
 System.out.println("Resultado: "+x.prefijar(p));
 System.out.println("Espacios: "+x.contarEsp());
 }
}