import java.util.*;
public class InventarioMain{
 public static void main(String[]a){System.out.println("hola");}
}
