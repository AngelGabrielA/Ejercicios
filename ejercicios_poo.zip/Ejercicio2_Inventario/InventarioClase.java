public class InventarioClase {
    private int x;
    public InventarioClase(){}
}
