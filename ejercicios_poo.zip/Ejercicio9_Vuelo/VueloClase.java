public class VueloClase {
    private int x;
    public VueloClase(){}
}
