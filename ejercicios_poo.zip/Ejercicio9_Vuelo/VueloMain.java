import java.util.*;
public class VueloMain{
 public static void main(String[]a){System.out.println("hola");}
}
