import java.util.*;
public class RectanguloMain{
 public static void main(String[]args){
 Scanner sc=new Scanner(System.in);
 System.out.print("Base: ");double b=sc.nextDouble();
 System.out.print("Altura: ");double h=sc.nextDouble();
 sc.nextLine();
 System.out.print("Etiqueta: ");String e=sc.nextLine();
 Rectangulo r=new Rectangulo(b,h,e);
 System.out.println("Area: "+r.area());
 System.out.println("Perimetro: "+r.perimetro());
 }
}