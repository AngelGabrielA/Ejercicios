public class Rectangulo{
 private double base,altura; private String etiqueta;
 public Rectangulo(double b,double h,String e){base=b;altura=h;etiqueta=e;}
 public double getBase(){return base;} public void setBase(double v){base=v;}
 public double getAltura(){return altura;} public void setAltura(double v){altura=v;}
 public String getEtiqueta(){return etiqueta;} public void setEtiqueta(String v){etiqueta=v;}
 public double area(){return base*altura;}
 public double perimetro(){return 2*(base+altura);}
}