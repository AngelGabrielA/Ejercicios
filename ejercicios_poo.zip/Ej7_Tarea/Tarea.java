public class Tarea{
 private String desc; private String prio; private boolean comp;
 public Tarea(String d,String p,boolean c){desc=d;prio=p;comp=c;}
 public String getDesc(){return desc;} public void setDesc(String v){desc=v;}
 public String getPrio(){return prio;} public void setPrio(String v){prio=v;}
 public boolean isComp(){return comp;} public void setComp(boolean v){comp=v;}
 public void completar(){comp=true;}
 public boolean urgente(){return prio.equalsIgnoreCase("Alta") && !comp;}
}