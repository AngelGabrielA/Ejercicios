import java.util.*;
public class TareaMain{
 public static void main(String[]a){
 Scanner sc=new Scanner(System.in);
 System.out.print("Desc: ");String d=sc.nextLine();
 System.out.print("Prio: ");String p=sc.nextLine();
 Tarea t=new Tarea(d,p,false);
 t.completar();
 System.out.println("Urgente? "+t.urgente());
 }
}