public class LibrosClase {
    private int x;
    public LibrosClase(){}
}
