import java.util.*;
public class LibrosMain{
 public static void main(String[]a){System.out.println("hola");}
}
