import java.util.*;
public class EmpleadoMain{
 public static void main(String[]a){System.out.println("hola");}
}
