public class EmpleadoClase {
    private int x;
    public EmpleadoClase(){}
}
