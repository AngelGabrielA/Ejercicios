public class Empleado{
 private String clave; private double salario; private double ret;
 public Empleado(String c,double s,double r){clave=c;salario=s;ret=r;}
 public String getClave(){return clave;} public void setClave(String v){clave=v;}
 public double getSalario(){return salario;} public void setSalario(double v){salario=v;}
 public double getRet(){return ret;} public void setRet(double v){ret=v;}
 public double neto(){return salario-(salario*(ret/100));}
 public void aumento(double p){salario+=salario*(p/100);}
}