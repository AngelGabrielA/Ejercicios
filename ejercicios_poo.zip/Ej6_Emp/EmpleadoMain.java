import java.util.*;
public class EmpleadoMain{
 public static void main(String[]args){
 Scanner sc=new Scanner(System.in);
 System.out.print("Clave: ");String c=sc.nextLine();
 System.out.print("Salario: ");double s=sc.nextDouble();
 System.out.print("Ret%: ");double r=sc.nextDouble();
 Empleado e=new Empleado(c,s,r);
 System.out.println("Neto: "+e.neto());
 System.out.print("Aumento%: ");double p=sc.nextDouble();
 e.aumento(p);
 System.out.println("Nuevo salario: "+e.getSalario());
 }
}