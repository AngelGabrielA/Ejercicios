public class Auto{
 private String marca; private int anio; private int vmax;
 public Auto(String m,int a,int v){marca=m;anio=a;vmax=v;}
 public String getMarca(){return marca;} public void setMarca(String v){marca=v;}
 public int getAnio(){return anio;} public void setAnio(int v){anio=v;}
 public int getVmax(){return vmax;} public void setVmax(int v){vmax=v;}
 public boolean encender(){return anio>1990;}
 public int antig(int actual){return actual-anio;}
}