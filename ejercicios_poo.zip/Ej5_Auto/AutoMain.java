import java.util.*;
public class AutoMain{
 public static void main(String[]args){
 Scanner sc=new Scanner(System.in);
 System.out.print("Marca: ");String m=sc.nextLine();
 System.out.print("Año: ");int a=sc.nextInt();
 System.out.print("VMax: ");int v=sc.nextInt();
 Auto x=new Auto(m,a,v);
 System.out.println("Encendido? "+x.encender());
 System.out.print("Año actual: ");int ac=sc.nextInt();
 System.out.println("Antig: "+x.antig(ac));
 }
}