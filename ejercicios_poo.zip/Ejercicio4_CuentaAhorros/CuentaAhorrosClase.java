public class CuentaAhorrosClase {
    private int x;
    public CuentaAhorrosClase(){}
}
