import java.util.*;
public class CuentaAhorrosMain{
 public static void main(String[]a){System.out.println("hola");}
}
