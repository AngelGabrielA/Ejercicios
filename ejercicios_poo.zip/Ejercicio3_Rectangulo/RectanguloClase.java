public class RectanguloClase {
    private int x;
    public RectanguloClase(){}
}
