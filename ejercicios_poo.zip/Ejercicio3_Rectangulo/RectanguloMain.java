import java.util.*;
public class RectanguloMain{
 public static void main(String[]a){System.out.println("hola");}
}
